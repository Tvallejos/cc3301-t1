typedef unsigned int uint;
uint borrar_bits(uint x, uint pat, int len);
char *reemplazo(char *s, char c, char *pal);
void reemplazar(char *s, char c, char *pal);
